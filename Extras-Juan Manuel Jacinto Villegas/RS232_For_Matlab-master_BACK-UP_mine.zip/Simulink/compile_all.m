
mex RS232_Buffer_Size.cpp -lRS232.lib
mex RS232_Create_Buffer.cpp -lRS232.lib
mex RS232_PeekB_Buffer.cpp -lRS232.lib
mex RS232_ReadB_Buffer.cpp -lRS232.lib
mex RS232_Read_Buffer.cpp -lRS232.lib
mex RS232_Read_Fix_Format.cpp -lRS232.lib
mex RS232_Read_Format.cpp -lRS232.lib
mex RS232_Setup.cpp -lRS232.lib
mex RS232_SynchB_Buffer.cpp -lRS232.lib
mex RS232_Wait_Buffer_Synch.cpp -lRS232.lib
mex RS232_WriteString.cpp -lRS232.lib
mex RS232_Write_Binary.cpp -lRS232.lib
mex RS232_Write_Format.cpp -lRS232.lib
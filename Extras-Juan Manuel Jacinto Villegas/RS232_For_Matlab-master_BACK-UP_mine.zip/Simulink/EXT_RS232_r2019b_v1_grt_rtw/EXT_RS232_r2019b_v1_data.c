/*
 * EXT_RS232_r2019b_v1_data.c
 *
 * Code generation for model "EXT_RS232_r2019b_v1".
 *
 * Model version              : 1.1276
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Wed May 20 18:02:51 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "EXT_RS232_r2019b_v1.h"
#include "EXT_RS232_r2019b_v1_private.h"

/* Block parameters (default storage) */
P_EXT_RS232_r2019b_v1_T EXT_RS232_r2019b_v1_P = {
  /* Computed Parameter: setup1_P1_Size
   * Referenced by: '<Root>/setup1'
   */
  { 1.0, 1.0 },

  /* Expression: port
   * Referenced by: '<Root>/setup1'
   */
  4.0,

  /* Computed Parameter: setup1_P2_Size
   * Referenced by: '<Root>/setup1'
   */
  { 1.0, 1.0 },

  /* Expression: baudrate
   * Referenced by: '<Root>/setup1'
   */
  11.0,

  /* Computed Parameter: setup1_P3_Size
   * Referenced by: '<Root>/setup1'
   */
  { 1.0, 1.0 },

  /* Expression: databit
   * Referenced by: '<Root>/setup1'
   */
  1.0,

  /* Computed Parameter: setup1_P4_Size
   * Referenced by: '<Root>/setup1'
   */
  { 1.0, 1.0 },

  /* Expression: stopbit
   * Referenced by: '<Root>/setup1'
   */
  1.0,

  /* Computed Parameter: setup1_P5_Size
   * Referenced by: '<Root>/setup1'
   */
  { 1.0, 1.0 },

  /* Expression: parity
   * Referenced by: '<Root>/setup1'
   */
  1.0,

  /* Computed Parameter: readformat1_P1_Size
   * Referenced by: '<Root>/readformat1'
   */
  { 1.0, 27.0 },

  /* Computed Parameter: readformat1_P1
   * Referenced by: '<Root>/readformat1'
   */
  { 85.0, 65.0, 69.0, 77.0, 32.0, 37.0, 100.0, 44.0, 32.0, 37.0, 100.0, 44.0,
    32.0, 37.0, 102.0, 44.0, 32.0, 37.0, 100.0, 44.0, 32.0, 37.0, 100.0, 92.0,
    114.0, 92.0, 110.0 },

  /* Computed Parameter: readformat1_P2_Size
   * Referenced by: '<Root>/readformat1'
   */
  { 1.0, 1.0 },

  /* Expression: nCharTerm
   * Referenced by: '<Root>/readformat1'
   */
  2.0,

  /* Computed Parameter: readformat1_P3_Size
   * Referenced by: '<Root>/readformat1'
   */
  { 1.0, 1.0 },

  /* Expression: sampTime
   * Referenced by: '<Root>/readformat1'
   */
  -1.0,

  /* Computed Parameter: TimerforRealTime_P1_Size
   * Referenced by: '<Root>/Timer for Real-Time'
   */
  { 1.0, 1.0 },

  /* Expression: 1
   * Referenced by: '<Root>/Timer for Real-Time'
   */
  1.0
};

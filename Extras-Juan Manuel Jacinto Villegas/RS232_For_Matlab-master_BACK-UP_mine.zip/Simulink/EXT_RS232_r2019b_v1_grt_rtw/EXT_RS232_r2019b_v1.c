/*
 * EXT_RS232_r2019b_v1.c
 *
 * Code generation for model "EXT_RS232_r2019b_v1".
 *
 * Model version              : 1.1276
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Wed May 20 18:02:51 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "EXT_RS232_r2019b_v1.h"
#include "EXT_RS232_r2019b_v1_private.h"
#include "EXT_RS232_r2019b_v1_dt.h"

/* Block signals (default storage) */
B_EXT_RS232_r2019b_v1_T EXT_RS232_r2019b_v1_B;

/* Block states (default storage) */
DW_EXT_RS232_r2019b_v1_T EXT_RS232_r2019b_v1_DW;

/* Real-time model */
RT_MODEL_EXT_RS232_r2019b_v1_T EXT_RS232_r2019b_v1_M_;
RT_MODEL_EXT_RS232_r2019b_v1_T *const EXT_RS232_r2019b_v1_M =
  &EXT_RS232_r2019b_v1_M_;

/*
 * Writes out MAT-file header.  Returns success or failure.
 * Returns:
 *      0 - success
 *      1 - failure
 */
int_T rt_WriteMat4FileHeader(FILE *fp, int32_T m, int32_T n, const char *name)
{
  typedef enum { ELITTLE_ENDIAN, EBIG_ENDIAN } ByteOrder;

  int16_T one = 1;
  ByteOrder byteOrder = (*((int8_T *)&one)==1) ? ELITTLE_ENDIAN : EBIG_ENDIAN;
  int32_T type = (byteOrder == ELITTLE_ENDIAN) ? 0: 1000;
  int32_T imagf = 0;
  int32_T name_len = (int32_T)strlen(name) + 1;
  if ((fwrite(&type, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&m, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&n, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&imagf, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(&name_len, sizeof(int32_T), 1, fp) == 0) ||
      (fwrite(name, sizeof(char), name_len, fp) == 0)) {
    return(1);
  } else {
    return(0);
  }
}                                      /* end rt_WriteMat4FileHeader */

/* Model step function */
void EXT_RS232_r2019b_v1_step(void)
{
  /* S-Function (RS232_Setup): '<Root>/setup1' */

  /* Level2 S-Function Block: '<Root>/setup1' (RS232_Setup) */
  {
    SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[0];
    sfcnOutputs(rts,0);
  }

  /* S-Function (RS232_Read_Format): '<Root>/readformat1' */

  /* Level2 S-Function Block: '<Root>/readformat1' (RS232_Read_Format) */
  {
    SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[1];
    sfcnOutputs(rts,0);
  }

  /* ToFile: '<Root>/To File' */
  {
    if (!(++EXT_RS232_r2019b_v1_DW.ToFile_IWORK.Decimation % 1) &&
        (EXT_RS232_r2019b_v1_DW.ToFile_IWORK.Count * (5 + 1)) + 1 < 100000000 )
    {
      FILE *fp = (FILE *) EXT_RS232_r2019b_v1_DW.ToFile_PWORK.FilePtr;
      if (fp != (NULL)) {
        real_T u[5 + 1];
        EXT_RS232_r2019b_v1_DW.ToFile_IWORK.Decimation = 0;
        u[0] = (((EXT_RS232_r2019b_v1_M->Timing.clockTick1+
                  EXT_RS232_r2019b_v1_M->Timing.clockTickH1* 4294967296.0)) *
                0.004);
        u[1] = EXT_RS232_r2019b_v1_B.readformat1_o3[0];
        u[2] = EXT_RS232_r2019b_v1_B.readformat1_o3[1];
        u[3] = EXT_RS232_r2019b_v1_B.readformat1_o3[2];
        u[4] = EXT_RS232_r2019b_v1_B.readformat1_o3[3];
        u[5] = EXT_RS232_r2019b_v1_B.readformat1_o3[4];
        if (fwrite(u, sizeof(real_T), 5 + 1, fp) != 5 + 1) {
          rtmSetErrorStatus(EXT_RS232_r2019b_v1_M,
                            "Error writing to MAT-file Temp_p1_250Hz.mat");
          return;
        }

        if (((++EXT_RS232_r2019b_v1_DW.ToFile_IWORK.Count) * (5 + 1))+1 >=
            100000000) {
          (void)fprintf(stdout,
                        "*** The ToFile block will stop logging data before\n"
                        "    the simulation has ended, because it has reached\n"
                        "    the maximum number of elements (100000000)\n"
                        "    allowed in MAT-file Temp_p1_250Hz.mat.\n");
        }
      }
    }
  }

  /* S-Function (sfun_rttime): '<Root>/Timer for Real-Time' */

  /* Level2 S-Function Block: '<Root>/Timer for Real-Time' (sfun_rttime) */
  {
    SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[2];
    sfcnOutputs(rts,0);
  }

  /* Matfile logging */
  rt_UpdateTXYLogVars(EXT_RS232_r2019b_v1_M->rtwLogInfo,
                      (EXT_RS232_r2019b_v1_M->Timing.t));

  /* External mode */
  rtExtModeUploadCheckTrigger(2);

  {                                    /* Sample time: [0.0s, 0.0s] */
    rtExtModeUpload(0, (real_T)EXT_RS232_r2019b_v1_M->Timing.t[0]);
  }

  {                                    /* Sample time: [0.004s, 0.0s] */
    rtExtModeUpload(1, (real_T)(((EXT_RS232_r2019b_v1_M->Timing.clockTick1+
      EXT_RS232_r2019b_v1_M->Timing.clockTickH1* 4294967296.0)) * 0.004));
  }

  /* signal main to stop simulation */
  {                                    /* Sample time: [0.0s, 0.0s] */
    if ((rtmGetTFinal(EXT_RS232_r2019b_v1_M)!=-1) &&
        !((rtmGetTFinal(EXT_RS232_r2019b_v1_M)-EXT_RS232_r2019b_v1_M->Timing.t[0])
          > EXT_RS232_r2019b_v1_M->Timing.t[0] * (DBL_EPSILON))) {
      rtmSetErrorStatus(EXT_RS232_r2019b_v1_M, "Simulation finished");
    }

    if (rtmGetStopRequested(EXT_RS232_r2019b_v1_M)) {
      rtmSetErrorStatus(EXT_RS232_r2019b_v1_M, "Simulation finished");
    }
  }

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++EXT_RS232_r2019b_v1_M->Timing.clockTick0)) {
    ++EXT_RS232_r2019b_v1_M->Timing.clockTickH0;
  }

  EXT_RS232_r2019b_v1_M->Timing.t[0] = EXT_RS232_r2019b_v1_M->Timing.clockTick0 *
    EXT_RS232_r2019b_v1_M->Timing.stepSize0 +
    EXT_RS232_r2019b_v1_M->Timing.clockTickH0 *
    EXT_RS232_r2019b_v1_M->Timing.stepSize0 * 4294967296.0;

  {
    /* Update absolute timer for sample time: [0.004s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The resolution of this integer timer is 0.004, which is the step size
     * of the task. Size of "clockTick1" ensures timer will not overflow during the
     * application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    EXT_RS232_r2019b_v1_M->Timing.clockTick1++;
    if (!EXT_RS232_r2019b_v1_M->Timing.clockTick1) {
      EXT_RS232_r2019b_v1_M->Timing.clockTickH1++;
    }
  }
}

/* Model initialize function */
void EXT_RS232_r2019b_v1_initialize(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)EXT_RS232_r2019b_v1_M, 0,
                sizeof(RT_MODEL_EXT_RS232_r2019b_v1_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&EXT_RS232_r2019b_v1_M->solverInfo,
                          &EXT_RS232_r2019b_v1_M->Timing.simTimeStep);
    rtsiSetTPtr(&EXT_RS232_r2019b_v1_M->solverInfo, &rtmGetTPtr
                (EXT_RS232_r2019b_v1_M));
    rtsiSetStepSizePtr(&EXT_RS232_r2019b_v1_M->solverInfo,
                       &EXT_RS232_r2019b_v1_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&EXT_RS232_r2019b_v1_M->solverInfo,
                          (&rtmGetErrorStatus(EXT_RS232_r2019b_v1_M)));
    rtsiSetRTModelPtr(&EXT_RS232_r2019b_v1_M->solverInfo, EXT_RS232_r2019b_v1_M);
  }

  rtsiSetSimTimeStep(&EXT_RS232_r2019b_v1_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&EXT_RS232_r2019b_v1_M->solverInfo,"FixedStepDiscrete");
  EXT_RS232_r2019b_v1_M->solverInfoPtr = (&EXT_RS232_r2019b_v1_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = EXT_RS232_r2019b_v1_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    EXT_RS232_r2019b_v1_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    EXT_RS232_r2019b_v1_M->Timing.sampleTimes =
      (&EXT_RS232_r2019b_v1_M->Timing.sampleTimesArray[0]);
    EXT_RS232_r2019b_v1_M->Timing.offsetTimes =
      (&EXT_RS232_r2019b_v1_M->Timing.offsetTimesArray[0]);

    /* task periods */
    EXT_RS232_r2019b_v1_M->Timing.sampleTimes[0] = (0.0);
    EXT_RS232_r2019b_v1_M->Timing.sampleTimes[1] = (0.004);

    /* task offsets */
    EXT_RS232_r2019b_v1_M->Timing.offsetTimes[0] = (0.0);
    EXT_RS232_r2019b_v1_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(EXT_RS232_r2019b_v1_M, &EXT_RS232_r2019b_v1_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = EXT_RS232_r2019b_v1_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    EXT_RS232_r2019b_v1_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(EXT_RS232_r2019b_v1_M, -1);
  EXT_RS232_r2019b_v1_M->Timing.stepSize0 = 0.004;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    EXT_RS232_r2019b_v1_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(EXT_RS232_r2019b_v1_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(EXT_RS232_r2019b_v1_M->rtwLogInfo, (NULL));
    rtliSetLogT(EXT_RS232_r2019b_v1_M->rtwLogInfo, "");
    rtliSetLogX(EXT_RS232_r2019b_v1_M->rtwLogInfo, "");
    rtliSetLogXFinal(EXT_RS232_r2019b_v1_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(EXT_RS232_r2019b_v1_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(EXT_RS232_r2019b_v1_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(EXT_RS232_r2019b_v1_M->rtwLogInfo, 1000);
    rtliSetLogDecimation(EXT_RS232_r2019b_v1_M->rtwLogInfo, 1);
    rtliSetLogY(EXT_RS232_r2019b_v1_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(EXT_RS232_r2019b_v1_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(EXT_RS232_r2019b_v1_M->rtwLogInfo, (NULL));
  }

  /* External mode info */
  EXT_RS232_r2019b_v1_M->Sizes.checksums[0] = (529615101U);
  EXT_RS232_r2019b_v1_M->Sizes.checksums[1] = (2982923562U);
  EXT_RS232_r2019b_v1_M->Sizes.checksums[2] = (2674638300U);
  EXT_RS232_r2019b_v1_M->Sizes.checksums[3] = (4194806890U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    EXT_RS232_r2019b_v1_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(EXT_RS232_r2019b_v1_M->extModeInfo,
      &EXT_RS232_r2019b_v1_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(EXT_RS232_r2019b_v1_M->extModeInfo,
                        EXT_RS232_r2019b_v1_M->Sizes.checksums);
    rteiSetTPtr(EXT_RS232_r2019b_v1_M->extModeInfo, rtmGetTPtr
                (EXT_RS232_r2019b_v1_M));
  }

  EXT_RS232_r2019b_v1_M->solverInfoPtr = (&EXT_RS232_r2019b_v1_M->solverInfo);
  EXT_RS232_r2019b_v1_M->Timing.stepSize = (0.004);
  rtsiSetFixedStepSize(&EXT_RS232_r2019b_v1_M->solverInfo, 0.004);
  rtsiSetSolverMode(&EXT_RS232_r2019b_v1_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  (void) memset(((void *) &EXT_RS232_r2019b_v1_B), 0,
                sizeof(B_EXT_RS232_r2019b_v1_T));

  /* states (dwork) */
  (void) memset((void *)&EXT_RS232_r2019b_v1_DW, 0,
                sizeof(DW_EXT_RS232_r2019b_v1_T));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    EXT_RS232_r2019b_v1_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.BTransTable = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.PTransTable = &rtPTransTable;
  }

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.sfcnInfo;
    EXT_RS232_r2019b_v1_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(EXT_RS232_r2019b_v1_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo,
      &EXT_RS232_r2019b_v1_M->Sizes.numSampTimes);
    EXT_RS232_r2019b_v1_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr
      (EXT_RS232_r2019b_v1_M)[0]);
    EXT_RS232_r2019b_v1_M->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr
      (EXT_RS232_r2019b_v1_M)[1]);
    rtssSetTPtrPtr(sfcnInfo,EXT_RS232_r2019b_v1_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(EXT_RS232_r2019b_v1_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(EXT_RS232_r2019b_v1_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput
      (EXT_RS232_r2019b_v1_M));
    rtssSetStepSizePtr(sfcnInfo, &EXT_RS232_r2019b_v1_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(EXT_RS232_r2019b_v1_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo,
      &EXT_RS232_r2019b_v1_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo,
      &EXT_RS232_r2019b_v1_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &EXT_RS232_r2019b_v1_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &EXT_RS232_r2019b_v1_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo,
      &EXT_RS232_r2019b_v1_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &EXT_RS232_r2019b_v1_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &EXT_RS232_r2019b_v1_M->solverInfoPtr);
  }

  EXT_RS232_r2019b_v1_M->Sizes.numSFcns = (3);

  /* register each child */
  {
    (void) memset((void *)
                  &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.childSFunctions[0], 0,
                  3*sizeof(SimStruct));
    EXT_RS232_r2019b_v1_M->childSfunctions =
      (&EXT_RS232_r2019b_v1_M->NonInlinedSFcns.childSFunctionPtrs[0]);
    EXT_RS232_r2019b_v1_M->childSfunctions[0] =
      (&EXT_RS232_r2019b_v1_M->NonInlinedSFcns.childSFunctions[0]);
    EXT_RS232_r2019b_v1_M->childSfunctions[1] =
      (&EXT_RS232_r2019b_v1_M->NonInlinedSFcns.childSFunctions[1]);
    EXT_RS232_r2019b_v1_M->childSfunctions[2] =
      (&EXT_RS232_r2019b_v1_M->NonInlinedSFcns.childSFunctions[2]);

    /* Level2 S-Function Block: EXT_RS232_r2019b_v1/<Root>/setup1 (RS232_Setup) */
    {
      SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod =
        EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset =
        EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, EXT_RS232_r2019b_v1_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &EXT_RS232_r2019b_v1_M->
                           NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &EXT_RS232_r2019b_v1_M->
                           NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &EXT_RS232_r2019b_v1_M->
                           NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn0.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn0.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &EXT_RS232_r2019b_v1_M->
          NonInlinedSFcns.Sfcn0.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((int32_T *)
            EXT_RS232_r2019b_v1_B.setup1_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((int32_T *)
            &EXT_RS232_r2019b_v1_B.setup1_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "setup1");
      ssSetPath(rts, "EXT_RS232_r2019b_v1/setup1");
      ssSetRTModel(rts,EXT_RS232_r2019b_v1_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 5);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)EXT_RS232_r2019b_v1_P.setup1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)EXT_RS232_r2019b_v1_P.setup1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)EXT_RS232_r2019b_v1_P.setup1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)EXT_RS232_r2019b_v1_P.setup1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)EXT_RS232_r2019b_v1_P.setup1_P5_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &EXT_RS232_r2019b_v1_DW.setup1_IWORK);
      ssSetPWork(rts, (void **) &EXT_RS232_r2019b_v1_DW.setup1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &EXT_RS232_r2019b_v1_DW.setup1_IWORK);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &EXT_RS232_r2019b_v1_DW.setup1_PWORK);
      }

      /* registration */
      RS232_Setup(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: EXT_RS232_r2019b_v1/<Root>/readformat1 (RS232_Read_Format) */
    {
      SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod =
        EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset =
        EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.inputOutputPortInfo2[1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, EXT_RS232_r2019b_v1_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &EXT_RS232_r2019b_v1_M->
                           NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &EXT_RS232_r2019b_v1_M->
                           NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &EXT_RS232_r2019b_v1_M->
                           NonInlinedSFcns.methods4[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.inputPortCoSimAttribute
          [0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          int32_T const **sfcnUPtrs = (int32_T const **)
            &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.UPtrs0;
          sfcnUPtrs[0] = EXT_RS232_r2019b_v1_B.setup1_o1;
          sfcnUPtrs[1] = &EXT_RS232_r2019b_v1_B.setup1_o1[1];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 2);
        }

        /* port 1 */
        {
          int32_T const **sfcnUPtrs = (int32_T const **)
            &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.UPtrs1;
          sfcnUPtrs[0] = &EXT_RS232_r2019b_v1_B.setup1_o2;
          ssSetInputPortSignalPtrs(rts, 1, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 3);
        _ssSetPortInfo2ForOutputUnits(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &EXT_RS232_r2019b_v1_M->
          NonInlinedSFcns.Sfcn1.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 2);
          ssSetOutputPortSignal(rts, 0, ((int32_T *)
            EXT_RS232_r2019b_v1_B.readformat1_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((int32_T *)
            &EXT_RS232_r2019b_v1_B.readformat1_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidth(rts, 2, 5);
          ssSetOutputPortSignal(rts, 2, ((real_T *)
            EXT_RS232_r2019b_v1_B.readformat1_o3));
        }
      }

      /* path info */
      ssSetModelName(rts, "readformat1");
      ssSetPath(rts, "EXT_RS232_r2019b_v1/readformat1");
      ssSetRTModel(rts,EXT_RS232_r2019b_v1_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 3);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       EXT_RS232_r2019b_v1_P.readformat1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       EXT_RS232_r2019b_v1_P.readformat1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       EXT_RS232_r2019b_v1_P.readformat1_P3_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &EXT_RS232_r2019b_v1_DW.readformat1_IWORK[0]);
      ssSetPWork(rts, (void **) &EXT_RS232_r2019b_v1_DW.readformat1_PWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &EXT_RS232_r2019b_v1_DW.readformat1_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 3);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &EXT_RS232_r2019b_v1_DW.readformat1_PWORK[0]);
      }

      /* registration */
      RS232_Read_Format(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 0, 0);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: EXT_RS232_r2019b_v1/<Root>/Timer for Real-Time (sfun_rttime) */
    {
      SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod =
        EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset =
        EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.inputOutputPortInfo2[2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, EXT_RS232_r2019b_v1_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &EXT_RS232_r2019b_v1_M->
                           NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &EXT_RS232_r2019b_v1_M->
                           NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &EXT_RS232_r2019b_v1_M->
                           NonInlinedSFcns.methods4[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts,
                         &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);
        _ssSetPortInfo2ForOutputUnits(rts,
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn2.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &EXT_RS232_r2019b_v1_M->
          NonInlinedSFcns.Sfcn2.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real_T *)
            &EXT_RS232_r2019b_v1_B.TimerforRealTime));
        }
      }

      /* states */
      ssSetDiscStates(rts, (real_T *)
                      &EXT_RS232_r2019b_v1_DW.TimerforRealTime_DSTATE);

      /* path info */
      ssSetModelName(rts, "Timer for Real-Time");
      ssSetPath(rts, "EXT_RS232_r2019b_v1/Timer for Real-Time");
      ssSetRTModel(rts,EXT_RS232_r2019b_v1_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 1);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       EXT_RS232_r2019b_v1_P.TimerforRealTime_P1_Size);
      }

      /* work vectors */
      ssSetRWork(rts, (real_T *) &EXT_RS232_r2019b_v1_DW.TimerforRealTime_RWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &EXT_RS232_r2019b_v1_M->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* RWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &EXT_RS232_r2019b_v1_DW.TimerforRealTime_RWORK);

        /* DSTATE */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_DOUBLE);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWorkUsedAsDState(rts, 1, 1);
        ssSetDWork(rts, 1, &EXT_RS232_r2019b_v1_DW.TimerforRealTime_DSTATE);
      }

      /* registration */
      sfun_rttime(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }
  }

  /* Matfile logging */
  rt_StartDataLoggingWithStartTime(EXT_RS232_r2019b_v1_M->rtwLogInfo, 0.0,
    rtmGetTFinal(EXT_RS232_r2019b_v1_M), EXT_RS232_r2019b_v1_M->Timing.stepSize0,
    (&rtmGetErrorStatus(EXT_RS232_r2019b_v1_M)));

  /* Start for S-Function (RS232_Setup): '<Root>/setup1' */
  /* Level2 S-Function Block: '<Root>/setup1' (RS232_Setup) */
  {
    SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[0];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (RS232_Read_Format): '<Root>/readformat1' */
  /* Level2 S-Function Block: '<Root>/readformat1' (RS232_Read_Format) */
  {
    SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[1];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for ToFile: '<Root>/To File' */
  {
    FILE *fp = (NULL);
    char fileName[509] = "Temp_p1_250Hz.mat";
    if ((fp = fopen(fileName, "wb")) == (NULL)) {
      rtmSetErrorStatus(EXT_RS232_r2019b_v1_M,
                        "Error creating .mat file Temp_p1_250Hz.mat");
      return;
    }

    if (rt_WriteMat4FileHeader(fp, 5 + 1, 0, "datos")) {
      rtmSetErrorStatus(EXT_RS232_r2019b_v1_M,
                        "Error writing mat file header to file Temp_p1_250Hz.mat");
      return;
    }

    EXT_RS232_r2019b_v1_DW.ToFile_IWORK.Count = 0;
    EXT_RS232_r2019b_v1_DW.ToFile_IWORK.Decimation = -1;
    EXT_RS232_r2019b_v1_DW.ToFile_PWORK.FilePtr = fp;
  }

  /* Start for S-Function (sfun_rttime): '<Root>/Timer for Real-Time' */
  /* Level2 S-Function Block: '<Root>/Timer for Real-Time' (sfun_rttime) */
  {
    SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[2];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }
}

/* Model terminate function */
void EXT_RS232_r2019b_v1_terminate(void)
{
  /* Terminate for S-Function (RS232_Setup): '<Root>/setup1' */
  /* Level2 S-Function Block: '<Root>/setup1' (RS232_Setup) */
  {
    SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[0];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (RS232_Read_Format): '<Root>/readformat1' */
  /* Level2 S-Function Block: '<Root>/readformat1' (RS232_Read_Format) */
  {
    SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[1];
    sfcnTerminate(rts);
  }

  /* Terminate for ToFile: '<Root>/To File' */
  {
    FILE *fp = (FILE *) EXT_RS232_r2019b_v1_DW.ToFile_PWORK.FilePtr;
    if (fp != (NULL)) {
      char fileName[509] = "Temp_p1_250Hz.mat";
      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(EXT_RS232_r2019b_v1_M,
                          "Error closing MAT-file Temp_p1_250Hz.mat");
        return;
      }

      if ((fp = fopen(fileName, "r+b")) == (NULL)) {
        rtmSetErrorStatus(EXT_RS232_r2019b_v1_M,
                          "Error reopening MAT-file Temp_p1_250Hz.mat");
        return;
      }

      if (rt_WriteMat4FileHeader(fp, 5 + 1,
           EXT_RS232_r2019b_v1_DW.ToFile_IWORK.Count, "datos")) {
        rtmSetErrorStatus(EXT_RS232_r2019b_v1_M,
                          "Error writing header for datos to MAT-file Temp_p1_250Hz.mat");
      }

      if (fclose(fp) == EOF) {
        rtmSetErrorStatus(EXT_RS232_r2019b_v1_M,
                          "Error closing MAT-file Temp_p1_250Hz.mat");
        return;
      }

      EXT_RS232_r2019b_v1_DW.ToFile_PWORK.FilePtr = (NULL);
    }
  }

  /* Terminate for S-Function (sfun_rttime): '<Root>/Timer for Real-Time' */
  /* Level2 S-Function Block: '<Root>/Timer for Real-Time' (sfun_rttime) */
  {
    SimStruct *rts = EXT_RS232_r2019b_v1_M->childSfunctions[2];
    sfcnTerminate(rts);
  }
}

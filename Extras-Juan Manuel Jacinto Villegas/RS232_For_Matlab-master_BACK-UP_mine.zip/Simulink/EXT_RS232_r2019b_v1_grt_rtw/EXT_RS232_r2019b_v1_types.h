/*
 * EXT_RS232_r2019b_v1_types.h
 *
 * Code generation for model "EXT_RS232_r2019b_v1".
 *
 * Model version              : 1.1276
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Wed May 20 18:02:51 2020
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_EXT_RS232_r2019b_v1_types_h_
#define RTW_HEADER_EXT_RS232_r2019b_v1_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"

/* Parameters (default storage) */
typedef struct P_EXT_RS232_r2019b_v1_T_ P_EXT_RS232_r2019b_v1_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_EXT_RS232_r2019b_v1_T RT_MODEL_EXT_RS232_r2019b_v1_T;

#endif                             /* RTW_HEADER_EXT_RS232_r2019b_v1_types_h_ */
